# Practical AI learning kit

Open this as a separate learning workspace. `program_labs/README.md` explains six runnable offline exercises. `practical_programs.json` contains the three substantial academy programs. `program_content/` contains their individual Markdown sessions. `imported_curriculum.json` contains the original source library, Accelerator and Tutor. `starter/` contains the original Accelerator capstone. Course documents are educational reference material; no upstream skill is automatically activated. No credentials or paid model calls are required for the offline exercises.
